library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = "Data Science Philippines Dec 2015",  titleWidth = 350),
 
  dashboardSidebar(
    sidebarMenu(
      menuItem("Control Widgets", tabName = "dashboard", icon = icon("dashboard"))
     
    )
  ),

  dashboardBody(
    tabItems(
      # First tab content
      tabItem(tabName = "dashboard",
              fluidRow(
                
                column(3,
                       h3("Buttons"),
                       actionButton("action", label = "Action"),
                       br(),
                       br(), 
                       submitButton("Submit")),
                
                column(3,
                       h3("Single checkbox"),
                       checkboxInput("checkbox", label = "Choice A", value = TRUE)),
                
                column(3, 
                       checkboxGroupInput("checkGroup", 
                                          label = h3("Checkbox group"), 
                                          choices = list("Choice 1" = 1, 
                                                         "Choice 2" = 2, "Choice 3" = 3),
                                          selected = 1)),
                
                column(3, 
                       dateInput("date", 
                                 label = h3("Date input"), 
                                 value = "2014-01-01"))   
              ),
              
              fluidRow(
                
                column(3,
                       dateRangeInput("dates", label = h3("Date range"))),
                
                column(3,
                       fileInput("file", label = h3("File input"))),
                
                column(3, 
                       h3("Help text"),
                       helpText("Note: help text isn't a true widget,", 
                                "but it provides an easy way to add text to",
                                "accompany other widgets.")),
                
                column(3, 
                       numericInput("num", 
                                    label = h3("Numeric input"), 
                                    value = 1))   
              ),
              
              fluidRow(
                
                column(3,
                       radioButtons("radio", label = h3("Radio buttons"),
                                    choices = list("Choice 1" = 1, "Choice 2" = 2,
                                                   "Choice 3" = 3),selected = 1)),
                
                column(3,
                       selectInput("select", label = h3("Select box"), 
                                   choices = list("Choice 1" = 1, "Choice 2" = 2,
                                                  "Choice 3" = 3), selected = 1)),
                
                column(3, 
                       sliderInput("slider1", label = h3("Sliders"),
                                   min = 0, max = 100, value = 50),
                       sliderInput("slider2", "",
                                   min = 0, max = 100, value = c(25, 75))
                ),
                
                column(3, 
                       textInput("text", label = h3("Text input"), 
                                 value = "Enter text..."))   
              )
             
              
              
              
      )

      
     
      
      )
  )
)

server <- function(input, output) {
  output$text1 <- renderText({ 
    "You have selected this"
  })
  
  set.seed(122)
  histdata <- rnorm(500)
  
  output$plot1 <- renderPlot({
    if (is.null(input$orders) || is.null(input$fill))
      return()
    
    data <- histdata[seq(1, input$orders)]
    color <- input$fill
    if (color == "none")
      color <- NULL
    hist(data, col = color)
  })
  
  output$plot2 <- renderPlot({
    spread <- as.numeric(input$spread) / 100
    x <- rnorm(1000)
    y <- x + rnorm(1000) * spread
    plot(x, y, pch = ".", col = "blue")
  })
}

shinyApp(ui, server)
